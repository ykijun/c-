// SUBMIT THIS FILE

#include "randomTextGenerator.h"
#include <fstream>
using namespace std;

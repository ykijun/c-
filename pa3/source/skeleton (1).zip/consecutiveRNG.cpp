// SUBMIT THIS FILE

#include "consecutiveRNG.h"
